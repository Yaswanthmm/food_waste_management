import datetime
from datetime import datetime, timedelta
import os

from bson import ObjectId
from flask import Flask, request, render_template, session, redirect

import pymongo
my_collections = pymongo.MongoClient("mongodb://localhost:27017/")
my_db = my_collections['prevent_food_wastage']
admin_col = my_db['Admin']
recipient_col = my_db['Recipient']
contributor_col = my_db['Contributor']
food_col = my_db['Food']
donations_col = my_db['Donations']
meals_col = my_db['Meals']
items_donated_col = my_db['item_donated']
items_in_meals_col = my_db['items_in_meal']
meal_request_col = my_db['meal_request']


app = Flask(__name__)
app.secret_key = "food"

App_Root = os.path.dirname(__file__)
App_Root = App_Root + "/static"


if admin_col.count_documents({}) == 0:
    admin_col.insert_one({"name": "admin", "password": "admin", "role": "admin"})

status_preparing = "Preparing"
status_donated_to_admin = "Donated to Admin"
status_send_food_request = "Send Food Request"
status_cancel_request = "Request Cancel by Recipient"
status_accept_request = "Request Accepted by Admin"
status_reject_request = "Request Rejected by Admin"


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/adminLogin")
def adminLogin():
    return render_template("adminLogin.html")


@app.route("/adminLogin1", methods=['post'])
def adminLogin1():
    name = request.form.get("name")
    password = request.form.get("password")
    query = {"name": name, "password": password}
    admin = admin_col.find_one(query)

    if admin != None:
        session['admin_id'] = str(admin['_id'])
        session['role'] = 'Admin'
        return redirect("/adminHome")
    else:
        return render_template("msg.html", message="Invalid Login Details", color="bg-danger text-white")


@app.route("/adminHome")
def adminHome():
    return render_template("adminHome.html")


@app.route("/contributor")
def contributor():
    contributors = contributor_col.find()
    return render_template("contributor.html", contributors=contributors)


@app.route("/add_contributor")
def add_contributor():
    return render_template("add_contributor.html")


@app.route("/add_contributor1", methods=['post'])
def add_contributor1():
    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")
    phone = request.form.get("phone")
    type = request.form.get("type")
    type_name = request.form.get("type_name")
    address = request.form.get("address")
    description = request.form.get("description")
    status = "Unauthorised"
    query = {"$or": [{"email": email}, {"phone": phone}]}
    count = contributor_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", message="Duplicate Details", color="bg-danger text-white")
    else:
        query = {"name": name, "email": email, "password": password, "phone": phone, "type": type, "type_name": type_name, "address": address, "description": description, "status": status}
    contributor_col.insert_one(query)
    return redirect("/contributor")


@app.route("/activate_contributor")
def activate_contributor():
    contributor_id = ObjectId(request.args.get("contributor_id"))
    query = {'_id': ObjectId(contributor_id)}
    query1 = {"$set": {"status": "Authorised"}}
    contributor_col .update_one(query, query1)
    return redirect("/contributor")


@app.route("/inactivate_contributor")
def inactivate_contributor():
    contributor_id = ObjectId(request.args.get("contributor_id"))
    query = {'_id': ObjectId(contributor_id)}
    query1 = {"$set": {"status": "Unauthorised"}}
    contributor_col .update_one(query, query1)
    return redirect("/contributor")


@app.route("/contributor_login")
def contributor_login():
    return render_template("contributor_login.html")


@app.route("/contributor_login1", methods=['post'])
def contributor_login1():
    email = request.form.get('email')
    password = request.form.get('password')
    query = {"email": email, "password": password}
    count = contributor_col.count_documents(query)
    if count > 0:
        contributor = contributor_col.find_one(query)
        if contributor["status"] == "Authorised":
            session['contributor_id'] = str(contributor['_id'])
            session['role'] = 'Contributor'
            return redirect("/contributor_home")
        else:
            return render_template("msg.html", message="Contributor is Not Authorised", color="bg-danger text-white")
    else:
        return render_template("msg.html", message="Invalid Login Details", color="bg-danger text-white")


@app.route("/contributor_home")
def contributor_home():
    return render_template("contributor_home.html")


@app.route("/recipient_login")
def recipient_login():
    return render_template("recipient_login.html")


@app.route("/recipient_login1", methods=['post'])
def recipient_login1():
    email = request.form.get('email')
    password = request.form.get('password')
    query = {"email": email, "password": password}
    count = recipient_col.count_documents(query)
    if count > 0:
        recipient = recipient_col.find_one(query)
        session['recipient_id'] = str(recipient['_id'])
        session['role'] = 'Recipient'
        return redirect("/recipient_home")
    else:
        return render_template("msg.html", message="Invalid Login Details", color="bg-danger text-white")


@app.route("/recipient_home")
def recipient_home():
    return render_template("recipient_home.html")


@app.route("/recipient_registration")
def recipient_registration():
    return render_template("recipient_registration.html")


@app.route("/recipient_registration1", methods=['post'])
def recipient_registration1():
    name = request.form.get('name')
    phone = request.form.get('phone')
    email = request.form.get('email')
    password = request.form.get('password')
    address = request.form.get("address")
    query = {"$or": [{"email": email}, {"phone": phone}]}
    count = recipient_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", message="Duplicate Details", color="bg-danger text-white")
    else:
        query = {"name": name, "email": email, "password": password, "phone": phone, "address": address}
    recipient_col.insert_one(query)
    return redirect("/recipient_login")


@app.route("/add_food")
def add_food():
    return render_template("add_food.html")


@app.route("/add_food1", methods=['post'])
def add_food1():
    food_name = request.form.get("food_name")
    units = request.form.get("units")

    picture = request.files.get('picture')
    path = App_Root + "/pictures/" + picture.filename
    picture.save(path)
    description = request.form.get("description")
    query = {"food_name": food_name, "units": units, "picture": picture.filename, "description": description}
    food_col.insert_one(query)
    return redirect("/view_food")


@app.route("/view_food")
def view_food():
    foods = food_col.find()
    return render_template("view_food.html", foods=foods)


@app.route("/donate_food")
def donate_food():
    food_id = request.args.get("food_id")
    expiry_date = request.args.get("expiry_date")
    expiry_date = expiry_date.replace("T", " ")
    expiry_date = datetime.strptime(expiry_date, '%Y-%m-%d %H:%M')
    quantity = request.args.get("quantity")
    contributor_id = session['contributor_id']
    date = datetime.now()
    query = {"contributor_id": ObjectId(contributor_id), "status": status_preparing}
    count = donations_col.count_documents(query)
    if count > 0:
        donation = donations_col.find_one(query)
        donation_id = donation['_id']
    else:
        query = {"contributor_id": ObjectId(contributor_id), "status": status_preparing, "date": date}
        result = donations_col.insert_one(query)
        donation_id = result.inserted_id
    query = {"food_id": ObjectId(food_id), "donation_id": ObjectId(donation_id)}
    count = items_donated_col.count_documents(query)
    if count == 0:
        query = {"food_id": ObjectId(food_id), "donation_id": ObjectId(donation_id), "quantity": int(quantity), "date": date, "expiry_date": expiry_date}
        items_donated_col.insert_one(query)
        return redirect("/view_donations")
    else:
        items_donated = items_donated_col.find_one(query)
        items_donated_id = items_donated['_id']
        quantity1 = items_donated['quantity']
        quantity = int(quantity1) + int(quantity)
        query = {"_id": ObjectId(items_donated_id)}
        query1 = {"$set": {"quantity": quantity}}
        items_donated_col.update_one(query, query1)
        return redirect("/view_donations")


@app.route("/view_donations")
def view_donations():
    if session['role'] == "Contributor":
        contributor_id = session['contributor_id']
        query = {"contributor_id": ObjectId(contributor_id)}
    elif session['role'] == "Admin":
        query = {"status": {"$nin": [status_preparing]}}
    donations = donations_col.find(query)
    return render_template("view_donations.html", get_expiry_date=get_expiry_date,  get_quantity_zero=get_quantity_zero, donations=donations, status_donated_to_admin=status_donated_to_admin, status_preparing=status_preparing, get_food_id=get_food_id, get_contributor_id=get_contributor_id, get_item_donated_by_donation_id=get_item_donated_by_donation_id)


def get_contributor_id(contributor_id):
    query = {"_id": ObjectId(contributor_id)}
    contributor = contributor_col.find_one(query)
    return contributor


def get_food_id(food_id):
    query = {"_id": ObjectId(food_id)}
    food = food_col.find_one(query)
    return food


def get_item_donated_by_donation_id(donation_id):
    query = {"donation_id": ObjectId(donation_id)}
    items_donated = items_donated_col.find(query)
    return items_donated


@app.route("/donate_now")
def donate_now():
    donation_id = ObjectId(request.args.get("donation_id"))
    query = {'_id': ObjectId(donation_id)}
    query1 = {"$set": {"status": status_donated_to_admin}}
    donations_col .update_one(query, query1)
    return redirect("/view_donations")


@app.route("/create_meal")
def create_meal():
    meal_id = request.args.get('meal_id')
    item_donated_id = request.args.get("item_donated_id")
    item_donated = []
    meals = []
    if item_donated_id!='None':
        query = {"_id": item_donated_id}
        meals = meals_col.find()
        item_donated = items_donated_col.find_one(query)
    meal = None
    if meal_id != None:
        meal = meals_col.find_one({"_id": ObjectId(meal_id)})
    return render_template("create_meal.html", meal=meal, get_meal_id_item_donated_id_plat_number=get_meal_id_item_donated_id_plat_number, get_plat_details=get_plat_details, item_donated=item_donated, meals=meals, meal_id=meal_id, str=str, int=int, item_donated_id=item_donated_id)


@app.route("/add_food_item")
def add_food_item():
    meal_id = request.args.get("meal_id")
    item_donated_id = request.args.get("item_donated_id")
    query = {"_id": ObjectId(item_donated_id)}
    item_donated = items_donated_col.find_one(query)
    quantity = item_donated['quantity']
    if int(quantity) > 0:
        plate_number = request.args.get("plate_number")
        query = {"meal_id": ObjectId(meal_id), "item_donated_id": ObjectId(item_donated_id), "plate_number": plate_number}
        items_in_meals_col.insert_one(query)
        query = {"_id": ObjectId(item_donated_id)}
        query1 = {"$set": {"quantity": int(quantity) - 1}}
        items_donated_col.update_one(query, query1)

        query = {'$push': {'available_food_items.'+str(plate_number): item_donated['food_id']}}
        meals_col.update_one({"_id": ObjectId(meal_id)}, query)
    else:
        return render_template("msg.html", message="Quantity Of Food is Completed", color="bg-danger text-white")
    return redirect("/create_meal?meal_id="+str(meal_id)+"&item_donated_id="+str(item_donated_id))


def get_plat_details(meal_id, plate_number):
    query = {"meal_id": ObjectId(meal_id), "plate_number": str(plate_number)}
    item_in_meals = items_in_meals_col.find(query)
    item_donated_ids = []
    for item_in_meal in item_in_meals:
        item_donated_ids.append({"_id": item_in_meal['item_donated_id']})
    if len(item_donated_ids) == 0:
        return
    query = {"$or": item_donated_ids}
    item_donateds = items_donated_col.find(query)
    food_ids = []
    for item_donated in item_donateds:
        food_ids.append({"_id": item_donated['food_id']})
    if len(food_ids) == 0:
        return None
    query = {"$or": food_ids}
    foods = food_col.find(query)
    return foods


def get_meal_id_item_donated_id_plat_number(meal_id, plate_number,item_donated_id):
    query = {"meal_id": ObjectId(meal_id), "plate_number": str(plate_number), "item_donated_id": ObjectId(item_donated_id)}
    count = items_in_meals_col.count_documents(query)
    if count == 0:
        return True
    else:
        return False


def get_quantity_zero(item_donated_id):
    query = {"_id": item_donated_id}
    item_donated = items_donated_col.find_one(query)
    quantity = item_donated['quantity']
    if int(quantity) <= 0:
        return False
    else:
        return True


def get_expiry_date(item_donated_id):
    query = {"_id": item_donated_id}
    item_donated = items_donated_col.find_one(query)
    expiry_date = item_donated['expiry_date']
    today = datetime.now()
    if today >= expiry_date:
        return False
    else:
        return True


@app.route("/add_meal")
def add_meal():
    today = datetime.now()
    query = {"expiry_date": {"$gte": today}}
    items_donated = items_donated_col.find(query)
    food_items = {}
    for item_donated in items_donated:
        if int(item_donated['quantity']) > 0:
            food_id = str(item_donated['food_id'])
            if food_id in food_items:
                food_items[food_id] = food_items[food_id] + item_donated['quantity']
            else:
                food_items[food_id] = item_donated['quantity']
    return render_template("add_meal.html", get_least_food_count=get_least_food_count, food_items=food_items, get_food_id=get_food_id)


@app.route("/add_meal1", methods=['post'])
def add_meal1():
    today = datetime.now()
    meal_title = request.form.get("meal_title")
    food_ids = request.form.getlist("food_ids")
    print(food_ids)
    food_ids2 = []
    for food_id in food_ids:
        food_ids2.append({"food_id": ObjectId(food_id),"expiry_date": {"$gte": today}})
    query = {"$or": food_ids2}
    items_donated = items_donated_col.find(query)
    items_donated = list(items_donated)
    print(items_donated)
    food_items = {}
    available_meals = 0
    for item_donated in items_donated:
        if int(item_donated['quantity']) > 0:
            food_id = str(item_donated['food_id'])
            if food_id in food_items:
                food_items[food_id] = int(food_items[food_id]) + int(item_donated['quantity'])
            else:
                food_items[food_id] = int(item_donated['quantity'])
    i = 0
    for food_id in food_items:
        if i == 0:
            available_meals = food_items[food_id]
            i = i + 1
        if available_meals > food_items[food_id]:
            available_meals = food_items[food_id]
    print(food_items)
    print(available_meals)
    date = datetime.now()
    expiry_date = request.form.get("expiry_date")
    expiry_date = expiry_date.replace("T", " ")
    expiry_date = datetime.strptime(expiry_date, '%Y-%m-%d %H:%M')

    description = request.form.get("description")
    picture = request.files.get('picture')
    path = App_Root + "/pictures/" + picture.filename
    picture.save(path)
    query = {"meal_title": meal_title, "available_meals": available_meals, "date": date, "expiry_date": expiry_date, "picture": picture.filename, "description": description}
    result = meals_col.insert_one(query)
    meal_id = result.inserted_id
    for i in range(1, int(available_meals)+1):
        for item_donated in items_donated:
            food_item = food_col.find_one({"_id":item_donated['food_id']})
            query = {"meal_id": ObjectId(meal_id), "food_id":food_item['_id'] ,"plate_number": str(i)}
            count = items_in_meals_col.count_documents(query)
            if count == 0:
                item_donated2 = items_donated_col.find_one({"_id": item_donated['_id']})
                if int(item_donated2['quantity']) > 0:
                    query = {"meal_id": ObjectId(meal_id), "item_donated_id": item_donated['_id'], "food_id":food_item['_id'], "plate_number": str(i)}
                    items_in_meals_col.insert_one(query)
                    query = {"_id":item_donated['_id']}
                    query2 = {"$set": {"quantity": int(item_donated2['quantity'])-1}}
                    items_donated_col.update_one(query, query2)
                    query = {'$push': {'available_food_items.' + str(i): item_donated['food_id']}}
                    meals_col.update_one({"_id": ObjectId(meal_id)}, query)
    return redirect("/create_meal")


@app.route("/view_meals")
def view_meals():
    today = datetime.now()
    query = {"expiry_date": {"$gte": today}}
    meals = meals_col.find(query)
    return render_template("view_meals.html", meals=meals, int=int)


@app.route("/view_plates")
def view_plates():
    available_meals = request.args.get("available_meals")
    meal_id = request.args.get("meal_id")
    query = {"_id": ObjectId(meal_id)}
    meal = meals_col.find_one(query)
    return render_template("view_plates.html", meal=meal, get_food_id=get_food_id,available_meals=int(available_meals), str=str)


@app.route("/send_food_request")
def send_food_request():
    meal_id = request.args.get("meal_id")
    recipient_id = session['recipient_id']
    required_meal = request.args.get("required_meal")
    date = datetime.now()
    status = status_send_food_request
    query = {"meal_id": ObjectId(meal_id), "recipient_id": ObjectId(recipient_id),"required_meal": required_meal, "date": date, "status": status}
    meal_request_col.insert_one(query)

    query = {"_id": ObjectId(meal_id)}
    meal = meals_col.find_one(query)
    available_meals = meal['available_meals']
    available_meals = int(available_meals) - int(required_meal)
    query1 = {"$set": {"available_meals": available_meals}}
    meals_col.update_one(query, query1)
    return render_template("msg.html", message="Request Sent Successfully", color="bg-success text-white")


@app.route("/view_requested_meals")
def view_requested_meals():
    query = {}
    if session['role'] == "Recipient":
        recipient_id = session['recipient_id']
        query = {"recipient_id": ObjectId(recipient_id)}
    elif session['role'] == "Admin":
        meal_requests = meal_request_col.find()
        meal_request_ids = []
        for meal_request in meal_requests:
            if meal_request != None:
                meal_request_ids.append({"_id": meal_request['_id']})
                query = {"$or": meal_request_ids}
    meal_requests = meal_request_col.find(query)
    return render_template("view_requested_meals.html", status_send_food_request=status_send_food_request,meal_requests=meal_requests, get_meal_id=get_meal_id, get_recipient_id=get_recipient_id)


def get_meal_id(meal_id):
    query = {"_id": ObjectId(meal_id)}
    meal = meals_col.find_one(query)
    return meal


def get_recipient_id(recipient_id):
    query = {"_id": ObjectId(recipient_id)}
    recipient = recipient_col.find_one(query)
    return recipient


@app.route("/cancel_request")
def cancel_request():
    meal_id = request.args.get("meal_id")
    query = {"_id": ObjectId(meal_id)}
    required_meal = request.args.get("required_meal")
    meal = meals_col.find_one(query)
    available_meals = meal['available_meals']
    available_meals = int(available_meals) + int(required_meal)
    query1 = {"$set": {"available_meals": available_meals}}
    meals_col.update_one(query, query1)

    meal_request_id = request.args.get("meal_request_id")
    query = {"_id": ObjectId(meal_request_id)}
    query1 = {"$set": {"status": status_cancel_request}}
    meal_request_col.update_one(query, query1)
    return redirect("/view_requested_meals?meal_id="+str(meal_id)+"&meal_request_id="+str(meal_request_id))


@app.route("/accept_request")
def accept_request():
    meal_id = request.args.get("meal_id")
    meal_request_id = request.args.get("meal_request_id")
    query = {"_id": ObjectId(meal_request_id)}
    query1 = {"$set": {"status": status_accept_request}}
    meal_request_col.update_one(query, query1)
    return redirect("/view_requested_meals?meal_id="+str(meal_id)+"&meal_request_id="+str(meal_request_id))


@app.route("/reject_request")
def reject_request():
    meal_id = request.args.get("meal_id")
    query = {"_id": ObjectId(meal_id)}
    required_meal = request.args.get("required_meal")
    meal = meals_col.find_one(query)
    available_meals = meal['available_meals']
    available_meals = int(available_meals) + int(required_meal)
    query1 = {"$set": {"available_meals": available_meals}}
    meals_col.update_one(query, query1)

    meal_request_id = request.args.get("meal_request_id")
    query = {"_id": ObjectId(meal_request_id)}
    query1 = {"$set": {"status": status_reject_request}}
    meal_request_col.update_one(query, query1)
    return redirect("/view_requested_meals?meal_id="+str(meal_id)+"&meal_request_id="+str(meal_request_id))


def get_least_food_count():
    today = datetime.now()
    query = {"expiry_date": {"$gte": today}}
    items_donated = items_donated_col.find(query)
    items_donated = list(items_donated)
    least_count = 0
    i = 0
    for item_donated in items_donated:
        quantity = int(item_donated['quantity'])
        if i == 0:
            least_count = int(quantity)
        if least_count > int(quantity):
            least_count = quantity
        if int(item_donated['quantity']) != 0:
            i = i+1
    return least_count


@app.route("/logout")
def logout():
    session.clear()
    return render_template("index.html")


app.run(debug=True)


